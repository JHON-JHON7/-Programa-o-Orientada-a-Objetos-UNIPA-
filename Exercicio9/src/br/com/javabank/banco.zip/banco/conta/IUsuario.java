package br.com.javabank.banco.conta;

public interface IUsuario {
    String getNome();
}
