package br.com.javabank.banco.conta;

public interface IContaUniversitaria extends IConta {
    boolean validarIdade(int idade);
}
